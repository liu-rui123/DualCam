#!/bin/bash

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
DERIVED_DATA_DIR="${RUNNER_TEMP:-$ROOT_DIR/.build}/DualCamDerivedData"
OUTPUT_PATH="${1:-$ROOT_DIR/DualCam-unsigned.ipa}"
BUNDLE_ID="${DUALCAM_BUNDLE_ID:-com.example.DualCam}"

if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "error: xcodebuild is required; run this script on macOS with Xcode installed." >&2
  exit 1
fi

if ! command -v xcodegen >/dev/null 2>&1; then
  echo "error: xcodegen is required; install it with: brew install xcodegen" >&2
  exit 1
fi

cd "$ROOT_DIR"
xcodegen generate

xcodebuild \
  -project DualCam.xcodeproj \
  -scheme DualCam \
  -configuration Release \
  -sdk iphoneos \
  -destination "generic/platform=iOS" \
  -derivedDataPath "$DERIVED_DATA_DIR" \
  PRODUCT_BUNDLE_IDENTIFIER="$BUNDLE_ID" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  COMPILER_INDEX_STORE_ENABLE=NO \
  build

APP_PATH="$DERIVED_DATA_DIR/Build/Products/Release-iphoneos/DualCam.app"
if [[ ! -d "$APP_PATH" ]]; then
  echo "error: expected app bundle was not produced at $APP_PATH" >&2
  exit 1
fi

PACKAGE_DIR="$(mktemp -d)"
trap 'rm -rf "$PACKAGE_DIR"' EXIT
mkdir -p "$PACKAGE_DIR/Payload"
ditto "$APP_PATH" "$PACKAGE_DIR/Payload/DualCam.app"

rm -f "$OUTPUT_PATH"
ditto -c -k --sequesterRsrc --keepParent "$PACKAGE_DIR/Payload" "$OUTPUT_PATH"

echo "Unsigned IPA created: $OUTPUT_PATH"
shasum -a 256 "$OUTPUT_PATH"

