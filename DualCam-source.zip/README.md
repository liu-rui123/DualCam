# 双摄相机（DualCam）

这是一个面向 iPhone 15 Pro Max、最低支持 iOS 17 的前后双摄相机原型。它使用苹果原生的 SwiftUI、AVFoundation、Core Image、Metal 和 PhotoKit，所有画面都在手机本地处理。

## 已实现

- 前置与后置广角同时预览；设备不支持时自动降级为后置单摄。
- 1080p、30 fps 实时合成，前摄默认显示为画中画。
- 合成照片和带麦克风声音的 H.264/AAC 视频，直接保存到系统相册。
- 拖动画中画、捏合缩放、交换前后画面主次。
- 选择前摄或后摄后调节变焦、曝光补偿、点击对焦，并可恢复自动模式。
- 处理权限拒绝、相机被占用、进入后台、系统压力中断和写入失败。
- 画中画、录像状态机和设备降级逻辑的单元测试。

## 当前限制

- 照片来自同步的 1080p 视频帧，不是摄像头的最高照片分辨率。
- 首版只使用“前摄＋后置广角”，不支持两个后置镜头同时录制。
- 双摄必须在真实 iPhone 上测试；iOS 模拟器只能检查编译、界面和单元测试。
- 当前 Windows 环境没有 Xcode，因此这里无法完成苹果 SDK 编译或真机性能验证。

## 借到 Mac 后的安装步骤

1. 从 Mac App Store 免费安装最新版 Xcode。
2. 安装 XcodeGen：

   ```bash
   brew install xcodegen
   ```

3. 在项目目录运行：

   ```bash
   xcodegen generate
   open DualCam.xcodeproj
   ```

4. 在 Xcode 左侧选择 `DualCam` 项目，再选择 `DualCam` Target → Signing & Capabilities。
5. 把 Bundle Identifier 从 `com.example.DualCam` 改成一个自己的唯一值，例如 `com.你的拼音.DualCam`。
6. 用 Apple 账号登录 Xcode，在 Team 中选择自己的 Personal Team。
7. 用数据线连接并信任 iPhone，在顶部设备菜单选择你的 iPhone，然后点击运行按钮。
8. 第一次启动时允许相机、麦克风和“添加到照片”权限。

免费 Personal Team 的签名通常 7 天到期，届时需要再次连接 Mac 运行安装。没有付费开发者会员时，朋友也要通过 Mac 用各自账号签名安装。

## 生成供全能签使用的 IPA

`scripts/build_unsigned_ipa.sh` 会使用苹果的 iPhoneOS SDK 编译真机版本，并打包为 `DualCam-unsigned.ipa`。这个 IPA 尚未签名，不能直接安装；需要在全能签中使用有效的 `.p12` 和匹配的 `.mobileprovision` 重新签名。

### 使用 GitHub Actions 免费生成

1. 把这个项目完整上传到自己的 GitHub 仓库。
2. 打开仓库的 **Actions** 页面，选择 **iOS build and tests**。
3. 点击 **Run workflow**，填写与你描述文件匹配的 Bundle ID。
4. 构建成功后，打开本次运行，在 **Artifacts** 下载 `DualCam-unsigned-ipa`。
5. 解压下载文件，得到 `DualCam-unsigned.ipa`，再导入全能签。

GitHub 保存该下载文件 14 天。每位朋友使用的描述文件都必须包含其设备 UDID；否则即使签名成功，也无法在朋友的手机上运行。

### 在 Mac 本地生成

```bash
brew install xcodegen
DUALCAM_BUNDLE_ID=com.你的标识.DualCam scripts/build_unsigned_ipa.sh
```

不要购买或导入来源不明的共享证书。共享企业证书可能随时被苹果撤销，`.p12` 还包含签名私钥。

## 真机验收清单

- 确认前后画面都在运动，并检查画中画不是旧帧。
- 竖屏、横屏分别拍照，结果应与取景布局一致。
- 连续录制至少 5 分钟，确认相册中的视频有声音且音画同步。
- 录制时拖动、缩放和交换画面，确认成片跟随变化。
- 分别选择前后镜头，检查曝光、变焦和点击对焦。
- 录制时切到后台再返回，确认已有视频能正常保存和播放。
- 观察手机明显发热时是否出现中断提示，而不是崩溃或留下损坏文件。

## 项目结构

- `DualCam/Capture`：相机会话、同步合成、Metal 预览和音视频写入。
- `DualCam/Models`：拍摄状态、设备降级决策和画中画布局。
- `DualCam/Views`：相机界面与手势控制。
- `DualCamTests`：不依赖真实摄像头的自动测试。
- `project.yml`：XcodeGen 工程定义。
- `.github/workflows/ios-build.yml`：免费的无签名构建和模拟器测试。
- `scripts/build_unsigned_ipa.sh`：在 macOS/GitHub Actions 生成供签名工具使用的未签名 IPA。
