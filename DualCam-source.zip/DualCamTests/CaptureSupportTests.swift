import XCTest
@testable import DualCam

final class CaptureSupportTests: XCTestCase {
    func testUsesDualCameraOnlyWhenDeviceAndPairSupportIt() {
        XCTAssertEqual(
            CaptureSupport.decide(isMultiCamSupported: true, pairSupported: true),
            .dualCamera
        )
    }

    func testFallsBackWhenMultiCamIsUnavailable() {
        let decision = CaptureSupport.decide(isMultiCamSupported: false, pairSupported: false)
        guard case .singleCamera(let reason) = decision else {
            return XCTFail("应该降级为单摄")
        }
        XCTAssertTrue(reason.contains("不支持"))
    }

    func testFallsBackWhenRequestedPairIsUnavailable() {
        let decision = CaptureSupport.decide(isMultiCamSupported: true, pairSupported: false)
        guard case .singleCamera(let reason) = decision else {
            return XCTFail("应该降级为单摄")
        }
        XCTAssertTrue(reason.contains("组合"))
    }
}

