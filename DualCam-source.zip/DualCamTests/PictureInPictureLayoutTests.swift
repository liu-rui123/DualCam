import XCTest
@testable import DualCam

final class PictureInPictureLayoutTests: XCTestCase {
    func testDefaultPictureInPictureStartsOnLeft() {
        XCTAssertLessThan(PictureInPictureLayout().center.x, 0.5)
    }

    private let portrait = CGSize(width: 1080, height: 1920)

    func testDefaultLayoutStaysInsideCanvas() {
        let layout = PictureInPictureLayout()
        let rect = layout.rect(in: portrait)
        let safe = CGRect(origin: .zero, size: portrait).insetBy(
            dx: portrait.width * PictureInPictureLayout.edgeMarginFraction,
            dy: portrait.height * PictureInPictureLayout.edgeMarginFraction
        )

        XCTAssertGreaterThanOrEqual(rect.minX, safe.minX)
        XCTAssertGreaterThanOrEqual(rect.minY, safe.minY)
        XCTAssertLessThanOrEqual(rect.maxX, safe.maxX)
        XCTAssertLessThanOrEqual(rect.maxY, safe.maxY)
    }

    func testResizeClampsToSupportedRange() {
        var layout = PictureInPictureLayout()
        layout.resize(by: 10, in: portrait)
        XCTAssertEqual(layout.widthFraction, PictureInPictureLayout.maximumWidthFraction)

        layout.resize(by: 0.01, in: portrait)
        XCTAssertEqual(layout.widthFraction, PictureInPictureLayout.minimumWidthFraction)
    }

    func testMoveClampsAtEdges() {
        var layout = PictureInPictureLayout()
        layout.move(to: CGPoint(x: -500, y: 3_000), in: portrait)
        let rect = layout.rect(in: portrait)

        XCTAssertGreaterThanOrEqual(rect.minX, portrait.width * PictureInPictureLayout.edgeMarginFraction)
        XCTAssertLessThanOrEqual(rect.maxY, portrait.height * (1 - PictureInPictureLayout.edgeMarginFraction))
    }

    func testHitTestingUsesRenderedRectangle() {
        let layout = PictureInPictureLayout()
        let rect = layout.rect(in: portrait)

        XCTAssertTrue(layout.contains(CGPoint(x: rect.midX, y: rect.midY), in: portrait))
        XCTAssertFalse(layout.contains(.zero, in: portrait))
    }
}
