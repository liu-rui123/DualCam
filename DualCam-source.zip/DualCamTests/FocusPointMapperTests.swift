import CoreGraphics
import XCTest
@testable import DualCam

final class FocusPointMapperTests: XCTestCase {
    func testPortraitBackCameraMapping() {
        let point = FocusPointMapper.devicePoint(
            from: CGPoint(x: 0.25, y: 0.75),
            orientation: .portrait,
            mirrored: false
        )
        XCTAssertEqual(point.x, 0.75, accuracy: 0.0001)
        XCTAssertEqual(point.y, 0.75, accuracy: 0.0001)
    }

    func testPortraitFrontCameraAccountsForMirroring() {
        let point = FocusPointMapper.devicePoint(
            from: CGPoint(x: 0.25, y: 0.75),
            orientation: .portrait,
            mirrored: true
        )
        XCTAssertEqual(point.x, 0.75, accuracy: 0.0001)
        XCTAssertEqual(point.y, 0.25, accuracy: 0.0001)
    }

    func testMappingClampsOutsideInput() {
        let point = FocusPointMapper.devicePoint(
            from: CGPoint(x: -1, y: 2),
            orientation: .landscapeLeft,
            mirrored: false
        )
        XCTAssertEqual(point, CGPoint(x: 0, y: 1))
    }
}
