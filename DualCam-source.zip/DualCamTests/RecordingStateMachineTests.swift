import XCTest
@testable import DualCam

final class RecordingStateMachineTests: XCTestCase {
    func testHappyPath() {
        var machine = RecordingStateMachine()
        let start = Date()

        XCTAssertEqual(machine.handle(.requestStart), .preparing)
        XCTAssertEqual(machine.handle(.firstFrame(start)), .recording(startedAt: start))
        XCTAssertEqual(machine.handle(.requestStop), .finishing)
        XCTAssertEqual(machine.handle(.finish), .idle)
    }

    func testInvalidEventsDoNotCorruptState() {
        var machine = RecordingStateMachine()

        XCTAssertEqual(machine.handle(.requestStop), .idle)
        XCTAssertEqual(machine.handle(.finish), .idle)
    }

    func testFailureCanBeReset() {
        var machine = RecordingStateMachine()

        XCTAssertEqual(machine.handle(.fail("磁盘已满")), .failed("磁盘已满"))
        XCTAssertEqual(machine.handle(.reset), .idle)
    }
}

