import XCTest
@testable import DualCam

final class FrameRenderPolicyTests: XCTestCase {
    func testBackModeRendersOnlyBackArrivals() {
        XCTAssertTrue(FrameRenderPolicy.shouldRender(
            mode: .back,
            arrival: .back,
            hasBackFrame: true,
            hasFrontFrame: false
        ))
        XCTAssertFalse(FrameRenderPolicy.shouldRender(
            mode: .back,
            arrival: .front,
            hasBackFrame: true,
            hasFrontFrame: true
        ))
    }

    func testFrontModeDoesNotWaitForBackCamera() {
        XCTAssertTrue(FrameRenderPolicy.shouldRender(
            mode: .front,
            arrival: .front,
            hasBackFrame: false,
            hasFrontFrame: true
        ))
    }

    func testDualModeWaitsForBothFramesAndUsesBackAsClock() {
        XCTAssertFalse(FrameRenderPolicy.shouldRender(
            mode: .dual,
            arrival: .back,
            hasBackFrame: true,
            hasFrontFrame: false
        ))
        XCTAssertFalse(FrameRenderPolicy.shouldRender(
            mode: .dual,
            arrival: .front,
            hasBackFrame: true,
            hasFrontFrame: true
        ))
        XCTAssertTrue(FrameRenderPolicy.shouldRender(
            mode: .dual,
            arrival: .back,
            hasBackFrame: true,
            hasFrontFrame: true
        ))
    }
}
