import XCTest
@testable import DualCam

final class CameraEffectsTests: XCTestCase {
    func testEffectsDefaultToOriginalWithoutWatermark() {
        let snapshot = CaptureLayoutStore().snapshot()
        XCTAssertEqual(snapshot.filter, .none)
        XCTAssertFalse(snapshot.dateWatermarkEnabled)
    }

    func testEffectsUpdateTogether() {
        let store = CaptureLayoutStore()
        store.update(filter: .film, dateWatermarkEnabled: true)
        let snapshot = store.snapshot()
        XCTAssertEqual(snapshot.filter, .film)
        XCTAssertTrue(snapshot.dateWatermarkEnabled)
    }

    func testAllExpectedFiltersAreAvailable() {
        XCTAssertEqual(CameraFilter.allCases.count, 6)
    }
}
