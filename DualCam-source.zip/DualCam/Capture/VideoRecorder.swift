import AVFoundation
import AudioToolbox
import CoreMedia
import CoreVideo
import Foundation

final class VideoRecorder {
    enum RecorderError: LocalizedError {
        case alreadyPrepared
        case cannotStart(String)
        case cannotAppend
        case noVideoFrames

        var errorDescription: String? {
            switch self {
            case .alreadyPrepared: return "录像器已经在工作。"
            case .cannotStart(let message): return "无法开始写入视频：\(message)"
            case .cannotAppend: return "视频帧写入失败。"
            case .noVideoFrames: return "录像没有收到有效画面。"
            }
        }
    }

    enum Event {
        case started(Date)
        case finished(Result<URL, Error>)
    }

    var onEvent: ((Event) -> Void)?

    private var writer: AVAssetWriter?
    private var videoInput: AVAssetWriterInput?
    private var audioInput: AVAssetWriterInput?
    private var adaptor: AVAssetWriterInputPixelBufferAdaptor?
    private var sessionStart: CMTime?
    private var outputURL: URL?
    private var isFinishing = false

    var isPrepared: Bool { writer != nil }

    func prepare(size: CGSize) throws {
        guard writer == nil else { throw RecorderError.alreadyPrepared }

        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("DualCam-\(UUID().uuidString)")
            .appendingPathExtension("mov")
        try? FileManager.default.removeItem(at: url)

        let writer = try AVAssetWriter(outputURL: url, fileType: .mov)
        let videoSettings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: Int(size.width),
            AVVideoHeightKey: Int(size.height),
            AVVideoCompressionPropertiesKey: [
                AVVideoAverageBitRateKey: 10_000_000,
                AVVideoExpectedSourceFrameRateKey: 30,
                AVVideoMaxKeyFrameIntervalKey: 60,
                AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel
            ]
        ]
        let videoInput = AVAssetWriterInput(mediaType: .video, outputSettings: videoSettings)
        videoInput.expectsMediaDataInRealTime = true

        let sourceAttributes: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: Int(size.width),
            kCVPixelBufferHeightKey as String: Int(size.height),
            kCVPixelBufferMetalCompatibilityKey as String: true
        ]
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: videoInput,
            sourcePixelBufferAttributes: sourceAttributes
        )

        let audioSettings: [String: Any] = [
            AVFormatIDKey: kAudioFormatMPEG4AAC,
            AVSampleRateKey: 44_100,
            AVNumberOfChannelsKey: 1,
            AVEncoderBitRateKey: 128_000
        ]
        let audioInput = AVAssetWriterInput(mediaType: .audio, outputSettings: audioSettings)
        audioInput.expectsMediaDataInRealTime = true

        guard writer.canAdd(videoInput), writer.canAdd(audioInput) else {
            throw RecorderError.cannotStart("设备不接受当前音视频格式。")
        }
        writer.add(videoInput)
        writer.add(audioInput)

        self.writer = writer
        self.videoInput = videoInput
        self.audioInput = audioInput
        self.adaptor = adaptor
        outputURL = url
        sessionStart = nil
    }

    func appendVideo(_ pixelBuffer: CVPixelBuffer, at presentationTime: CMTime) {
        guard !isFinishing, let writer, let videoInput, let adaptor else { return }

        if sessionStart == nil {
            guard writer.startWriting() else {
                finishWithFailure(writer.error ?? RecorderError.cannotStart("未知错误"))
                return
            }
            writer.startSession(atSourceTime: presentationTime)
            sessionStart = presentationTime
            onEvent?(.started(Date()))
        }

        guard writer.status == .writing else {
            finishWithFailure(writer.error ?? RecorderError.cannotAppend)
            return
        }
        if videoInput.isReadyForMoreMediaData, !adaptor.append(pixelBuffer, withPresentationTime: presentationTime) {
            finishWithFailure(writer.error ?? RecorderError.cannotAppend)
        }
    }

    func appendAudio(_ sampleBuffer: CMSampleBuffer) {
        guard
            !isFinishing,
            let writer,
            let audioInput,
            let sessionStart,
            writer.status == .writing,
            CMSampleBufferGetPresentationTimeStamp(sampleBuffer) >= sessionStart,
            audioInput.isReadyForMoreMediaData
        else { return }
        if !audioInput.append(sampleBuffer) {
            finishWithFailure(writer.error ?? RecorderError.cannotAppend)
        }
    }

    func finish() {
        guard !isFinishing, let writer else { return }
        isFinishing = true
        guard sessionStart != nil else {
            writer.cancelWriting()
            let url = outputURL
            reset()
            if let url { try? FileManager.default.removeItem(at: url) }
            onEvent?(.finished(.failure(RecorderError.noVideoFrames)))
            return
        }

        videoInput?.markAsFinished()
        audioInput?.markAsFinished()
        let url = outputURL
        writer.finishWriting { [weak self] in
            guard let self else { return }
            if writer.status == .completed, let url {
                self.reset()
                self.onEvent?(.finished(.success(url)))
            } else {
                let error = writer.error ?? RecorderError.cannotAppend
                self.reset()
                if let url { try? FileManager.default.removeItem(at: url) }
                self.onEvent?(.finished(.failure(error)))
            }
        }
    }

    func cancel() {
        writer?.cancelWriting()
        let url = outputURL
        reset()
        if let url { try? FileManager.default.removeItem(at: url) }
    }

    private func finishWithFailure(_ error: Error) {
        writer?.cancelWriting()
        let url = outputURL
        reset()
        if let url { try? FileManager.default.removeItem(at: url) }
        onEvent?(.finished(.failure(error)))
    }

    private func reset() {
        writer = nil
        videoInput = nil
        audioInput = nil
        adaptor = nil
        sessionStart = nil
        outputURL = nil
        isFinishing = false
    }
}
