import CoreVideo
import Foundation

final class PreviewFrameStore {
    private let lock = NSLock()
    private var frame: CVPixelBuffer?

    func update(_ frame: CVPixelBuffer) {
        lock.lock()
        self.frame = frame
        lock.unlock()
    }

    func latestFrame() -> CVPixelBuffer? {
        lock.lock()
        defer { lock.unlock() }
        return frame
    }
}

