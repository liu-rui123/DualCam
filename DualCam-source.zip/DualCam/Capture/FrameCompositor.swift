import CoreImage
import CoreMedia
import CoreVideo
import Foundation
import Metal

final class FrameCompositor {
    enum CompositorError: LocalizedError {
        case cannotCreatePixelBufferPool
        case cannotCreatePixelBuffer
        case cannotCreateImage

        var errorDescription: String? {
            switch self {
            case .cannotCreatePixelBufferPool: return "无法创建视频缓冲池。"
            case .cannotCreatePixelBuffer: return "无法创建合成视频帧。"
            case .cannotCreateImage: return "无法生成照片。"
            }
        }
    }

    private let context: CIContext
    private var pixelBufferPool: CVPixelBufferPool?
    private var poolSize: CGSize = .zero
    private let colorSpace = CGColorSpaceCreateDeviceRGB()

    init() {
        if let device = MTLCreateSystemDefaultDevice() {
            context = CIContext(mtlDevice: device, options: [.cacheIntermediates: false])
        } else {
            context = CIContext(options: [.cacheIntermediates: false])
        }
    }

    func compose(
        backBuffer: CVPixelBuffer,
        frontBuffer: CVPixelBuffer?,
        snapshot: CaptureLayoutStore.Snapshot
    ) throws -> CVPixelBuffer {
        let size = snapshot.orientation.outputSize
        let canvas = CGRect(origin: .zero, size: size)
        let backImage = CIImage(cvPixelBuffer: backBuffer)
        let frontImage = frontBuffer.map(CIImage.init(cvPixelBuffer:))

        let requestedMain = snapshot.mainRole == .front ? frontImage : backImage
        let requestedPiP = snapshot.mainRole == .front ? Optional(backImage) : frontImage
        let mainImage = requestedMain ?? backImage

        var composition = CIImage(color: .black).cropped(to: canvas)
        composition = aspectFill(mainImage, in: canvas).composited(over: composition)

        if let pipImage = requestedPiP {
            let uiRect = snapshot.layout.rect(in: size)
            let pipRect = CGRect(
                x: uiRect.minX,
                y: size.height - uiRect.maxY,
                width: uiRect.width,
                height: uiRect.height
            ).integral
            let borderRect = pipRect.insetBy(dx: -6, dy: -6).intersection(canvas)
            let border = CIImage(color: CIColor(red: 1, green: 1, blue: 1, alpha: 0.9))
                .cropped(to: borderRect)
            composition = border.composited(over: composition)
            composition = aspectFill(pipImage, in: pipRect).composited(over: composition)
        }

        let output = try makePixelBuffer(size: size)
        context.render(
            composition,
            to: output,
            bounds: canvas,
            colorSpace: colorSpace
        )
        return output
    }

    func makeCGImage(from pixelBuffer: CVPixelBuffer) throws -> CGImage {
        let image = CIImage(cvPixelBuffer: pixelBuffer)
        guard let cgImage = context.createCGImage(image, from: image.extent) else {
            throw CompositorError.cannotCreateImage
        }
        return cgImage
    }

    private func aspectFill(_ image: CIImage, in destination: CGRect) -> CIImage {
        guard !image.extent.isEmpty else { return image }
        let scale = max(
            destination.width / image.extent.width,
            destination.height / image.extent.height
        )
        let scaled = image.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        let translation = CGAffineTransform(
            translationX: destination.midX - scaled.extent.midX,
            y: destination.midY - scaled.extent.midY
        )
        return scaled.transformed(by: translation).cropped(to: destination)
    }

    private func makePixelBuffer(size: CGSize) throws -> CVPixelBuffer {
        if pixelBufferPool == nil || poolSize != size {
            let attributes: [CFString: Any] = [
                kCVPixelBufferPixelFormatTypeKey: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey: Int(size.width),
                kCVPixelBufferHeightKey: Int(size.height),
                kCVPixelBufferMetalCompatibilityKey: true,
                kCVPixelBufferIOSurfacePropertiesKey: [:]
            ]
            var newPool: CVPixelBufferPool?
            let status = CVPixelBufferPoolCreate(nil, nil, attributes as CFDictionary, &newPool)
            guard status == kCVReturnSuccess, let newPool else {
                throw CompositorError.cannotCreatePixelBufferPool
            }
            pixelBufferPool = newPool
            poolSize = size
        }

        var output: CVPixelBuffer?
        let status = CVPixelBufferPoolCreatePixelBuffer(nil, pixelBufferPool!, &output)
        guard status == kCVReturnSuccess, let output else {
            throw CompositorError.cannotCreatePixelBuffer
        }
        return output
    }
}

