import CoreImage
import CoreMedia
import CoreVideo
import Foundation
import Metal
import UIKit

final class FrameCompositor {
    enum CompositorError: LocalizedError {
        case cannotCreatePixelBufferPool
        case cannotCreatePixelBuffer
        case cannotCreateImage
        case missingCameraFrame

        var errorDescription: String? {
            switch self {
            case .cannotCreatePixelBufferPool: return "无法创建视频缓冲池。"
            case .cannotCreatePixelBuffer: return "无法创建合成视频帧。"
            case .cannotCreateImage: return "无法生成照片。"
            case .missingCameraFrame: return "摄像头暂时没有输出画面。"
            }
        }
    }

    private let context: CIContext
    private var pixelBufferPool: CVPixelBufferPool?
    private var poolSize: CGSize = .zero
    private let colorSpace = CGColorSpaceCreateDeviceRGB()
    private let watermarkFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "zh_CN")
        formatter.dateFormat = "yyyy-MM-dd  HH:mm:ss"
        return formatter
    }()
    private var cachedWatermarkSecond: String?
    private var cachedWatermarkImage: CIImage?

    init() {
        if let device = MTLCreateSystemDefaultDevice() {
            context = CIContext(mtlDevice: device, options: [.cacheIntermediates: false])
        } else {
            context = CIContext(options: [.cacheIntermediates: false])
        }
    }

    func compose(
        backBuffer: CVPixelBuffer?,
        frontBuffer: CVPixelBuffer?,
        snapshot: CaptureLayoutStore.Snapshot
    ) throws -> CVPixelBuffer {
        let size = snapshot.orientation.outputSize
        let canvas = CGRect(origin: .zero, size: size)
        let backImage = backBuffer.map(CIImage.init(cvPixelBuffer:))
        let frontImage = frontBuffer.map(CIImage.init(cvPixelBuffer:))

        let mainImage: CIImage
        let pipImage: CIImage?
        switch snapshot.displayMode {
        case .back:
            guard let backImage else { throw CompositorError.missingCameraFrame }
            mainImage = backImage
            pipImage = nil
        case .front:
            guard let frontImage else { throw CompositorError.missingCameraFrame }
            mainImage = frontImage
            pipImage = nil
        case .dual:
            guard let backImage, let frontImage else { throw CompositorError.missingCameraFrame }
            mainImage = snapshot.mainRole == .front ? frontImage : backImage
            pipImage = snapshot.mainRole == .front ? backImage : frontImage
        }

        var composition = CIImage(color: .black).cropped(to: canvas)
        composition = aspectFill(mainImage, in: canvas).composited(over: composition)

        if let pipImage {
            let uiRect = snapshot.layout.rect(in: size)
            let pipRect = CGRect(
                x: uiRect.minX,
                y: size.height - uiRect.maxY,
                width: uiRect.width,
                height: uiRect.height
            ).integral
            let roundedPiP = aspectFill(pipImage, in: pipRect)
            let mask = roundedRectangleMask(
                in: pipRect,
                radius: max(24, pipRect.width * 0.08)
            )
            composition = roundedPiP.applyingFilter(
                "CIBlendWithMask",
                parameters: [
                    kCIInputBackgroundImageKey: composition,
                    kCIInputMaskImageKey: mask
                ]
            )
        }

        composition = apply(snapshot.filter, to: composition).cropped(to: canvas)
        if snapshot.dateWatermarkEnabled {
            composition = addDateWatermark(to: composition, canvas: canvas)
        }

        let output = try makePixelBuffer(size: size)
        context.render(
            composition,
            to: output,
            bounds: canvas,
            colorSpace: colorSpace
        )
        return output
    }

    func makeCGImage(from pixelBuffer: CVPixelBuffer) throws -> CGImage {
        let image = CIImage(cvPixelBuffer: pixelBuffer)
        guard let cgImage = context.createCGImage(image, from: image.extent) else {
            throw CompositorError.cannotCreateImage
        }
        return cgImage
    }

    private func aspectFill(_ image: CIImage, in destination: CGRect) -> CIImage {
        guard !image.extent.isEmpty else { return image }
        let scale = max(
            destination.width / image.extent.width,
            destination.height / image.extent.height
        )
        let scaled = image.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        let translation = CGAffineTransform(
            translationX: destination.midX - scaled.extent.midX,
            y: destination.midY - scaled.extent.midY
        )
        return scaled.transformed(by: translation).cropped(to: destination)
    }

    private func roundedRectangleMask(in rect: CGRect, radius: CGFloat) -> CIImage {
        let parameters: [String: Any] = [
            "inputExtent": CIVector(cgRect: rect),
            "inputRadius": radius,
            "inputColor": CIColor(red: 1, green: 1, blue: 1, alpha: 1)
        ]
        return CIFilter(name: "CIRoundedRectangleGenerator", parameters: parameters)?
            .outputImage?
            .cropped(to: rect)
            ?? CIImage(color: .white).cropped(to: rect)
    }

    private func apply(_ filter: CameraFilter, to image: CIImage) -> CIImage {
        switch filter {
        case .none:
            return image
        case .vivid:
            return image.applyingFilter(
                "CIColorControls",
                parameters: [
                    kCIInputSaturationKey: 1.28,
                    kCIInputContrastKey: 1.08
                ]
            )
        case .mono:
            return image.applyingFilter("CIPhotoEffectMono")
        case .warm:
            return image.applyingFilter(
                "CIColorMatrix",
                parameters: [
                    "inputRVector": CIVector(x: 1.07, y: 0, z: 0, w: 0),
                    "inputGVector": CIVector(x: 0, y: 1.01, z: 0, w: 0),
                    "inputBVector": CIVector(x: 0, y: 0, z: 0.91, w: 0),
                    "inputAVector": CIVector(x: 0, y: 0, z: 0, w: 1)
                ]
            )
        case .cool:
            return image.applyingFilter(
                "CIColorMatrix",
                parameters: [
                    "inputRVector": CIVector(x: 0.94, y: 0, z: 0, w: 0),
                    "inputGVector": CIVector(x: 0, y: 1.01, z: 0, w: 0),
                    "inputBVector": CIVector(x: 0, y: 0, z: 1.08, w: 0),
                    "inputAVector": CIVector(x: 0, y: 0, z: 0, w: 1)
                ]
            )
        case .film:
            return image.applyingFilter("CIPhotoEffectTransfer")
        }
    }

    private func addDateWatermark(to image: CIImage, canvas: CGRect) -> CIImage {
        let second = watermarkFormatter.string(from: Date())
        let watermark: CIImage
        if cachedWatermarkSecond == second, let cachedWatermarkImage {
            watermark = cachedWatermarkImage
        } else {
            let size = CGSize(width: 390, height: 52)
            let format = UIGraphicsImageRendererFormat()
            format.opaque = false
            format.scale = 1
            let rendered = UIGraphicsImageRenderer(size: size, format: format).image { _ in
                let paragraph = NSMutableParagraphStyle()
                paragraph.alignment = .right
                let attributes: [NSAttributedString.Key: Any] = [
                    .font: UIFont.monospacedDigitSystemFont(ofSize: 25, weight: .semibold),
                    .foregroundColor: UIColor.white,
                    .strokeColor: UIColor.black.withAlphaComponent(0.75),
                    .strokeWidth: -3,
                    .paragraphStyle: paragraph
                ]
                second.draw(
                    in: CGRect(origin: .zero, size: size),
                    withAttributes: attributes
                )
            }
            watermark = CIImage(image: rendered) ?? CIImage.empty()
            cachedWatermarkSecond = second
            cachedWatermarkImage = watermark
        }

        let transform = CGAffineTransform(
            translationX: canvas.maxX - watermark.extent.width - 30,
            y: 28
        )
        return watermark.transformed(by: transform).composited(over: image)
    }

    private func makePixelBuffer(size: CGSize) throws -> CVPixelBuffer {
        if pixelBufferPool == nil || poolSize != size {
            let attributes: [CFString: Any] = [
                kCVPixelBufferPixelFormatTypeKey: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey: Int(size.width),
                kCVPixelBufferHeightKey: Int(size.height),
                kCVPixelBufferMetalCompatibilityKey: true,
                kCVPixelBufferIOSurfacePropertiesKey: [:]
            ]
            var newPool: CVPixelBufferPool?
            let status = CVPixelBufferPoolCreate(nil, nil, attributes as CFDictionary, &newPool)
            guard status == kCVReturnSuccess, let newPool else {
                throw CompositorError.cannotCreatePixelBufferPool
            }
            pixelBufferPool = newPool
            poolSize = size
        }

        var output: CVPixelBuffer?
        let status = CVPixelBufferPoolCreatePixelBuffer(nil, pixelBufferPool!, &output)
        guard status == kCVReturnSuccess, let output else {
            throw CompositorError.cannotCreatePixelBuffer
        }
        return output
    }
}
