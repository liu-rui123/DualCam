import Photos
import UIKit

enum PhotoLibrarySaver {
    static let albumName = "DualCam"

    enum SaveError: LocalizedError {
        case cannotCreateAsset

        var errorDescription: String? {
            "无法在系统照片中创建媒体文件。"
        }
    }

    static func save(
        image: UIImage,
        completion: @escaping (Bool, Error?) -> Void
    ) {
        saveAsset(
            creationRequest: { PHAssetChangeRequest.creationRequestForAsset(from: image) },
            completion: completion
        )
    }

    static func saveVideo(
        at url: URL,
        completion: @escaping (Bool, Error?) -> Void
    ) {
        saveAsset(
            creationRequest: { PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url) },
            completion: completion
        )
    }

    static func loadLatestThumbnail(
        targetSize: CGSize = CGSize(width: 160, height: 160),
        completion: @escaping (UIImage?) -> Void
    ) {
        guard let album = fetchAlbum() else {
            completion(nil)
            return
        }

        let options = PHFetchOptions()
        options.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: false)]
        options.fetchLimit = 1
        guard let asset = PHAsset.fetchAssets(in: album, options: options).firstObject else {
            completion(nil)
            return
        }

        let imageOptions = PHImageRequestOptions()
        imageOptions.deliveryMode = .highQualityFormat
        imageOptions.resizeMode = .exact
        imageOptions.isNetworkAccessAllowed = false
        PHImageManager.default().requestImage(
            for: asset,
            targetSize: targetSize,
            contentMode: .aspectFill,
            options: imageOptions
        ) { image, _ in
            completion(image)
        }
    }

    private static func saveAsset(
        creationRequest: @escaping () -> PHAssetChangeRequest?,
        completion: @escaping (Bool, Error?) -> Void
    ) {
        let existingAlbum = fetchAlbum()
        var requestFailed = false

        PHPhotoLibrary.shared().performChanges {
            guard
                let assetRequest = creationRequest(),
                let placeholder = assetRequest.placeholderForCreatedAsset
            else {
                requestFailed = true
                return
            }

            let assets = NSArray(object: placeholder)
            if let existingAlbum {
                PHAssetCollectionChangeRequest(for: existingAlbum)?.addAssets(assets)
            } else {
                let albumRequest = PHAssetCollectionChangeRequest
                    .creationRequestForAssetCollection(withTitle: albumName)
                albumRequest.addAssets(assets)
            }
        } completionHandler: { success, error in
            if requestFailed {
                completion(false, SaveError.cannotCreateAsset)
            } else {
                completion(success, error)
            }
        }
    }

    private static func fetchAlbum() -> PHAssetCollection? {
        let options = PHFetchOptions()
        options.predicate = NSPredicate(format: "title = %@", albumName)
        return PHAssetCollection.fetchAssetCollections(
            with: .album,
            subtype: .any,
            options: options
        ).firstObject
    }
}
