import AVFoundation
import Combine
import Photos
import UIKit

final class DualCameraController: NSObject, ObservableObject {
    @Published private(set) var availability: CaptureAvailability = .unknown
    @Published var captureMode: CaptureMode = .photo
    @Published private(set) var recordingState: RecordingState = .idle
    @Published private(set) var dualCameraActive = false
    @Published private(set) var fallbackMessage: String?
    @Published private(set) var displayMode: CameraDisplayMode = .dual
    @Published private(set) var mainRole: CameraRole = .back
    @Published private(set) var selectedRole: CameraRole = .back
    @Published private(set) var pipLayout = PictureInPictureLayout()
    @Published private(set) var orientation: CaptureOrientation = .portrait
    @Published private(set) var controlState = CameraControlState()
    @Published private(set) var latestThumbnail: UIImage?
    @Published var notice: String?

    let previewStore = PreviewFrameStore()

    private let captureQueue = DispatchQueue(label: "com.example.DualCam.capture", qos: .userInitiated)
    private let layoutStore = CaptureLayoutStore()
    private let compositor = FrameCompositor()
    private let recorder = VideoRecorder()

    private var session: AVCaptureSession?
    private var backDevice: AVCaptureDevice?
    private var frontDevice: AVCaptureDevice?
    private var backOutput: AVCaptureVideoDataOutput?
    private var frontOutput: AVCaptureVideoDataOutput?
    private var audioOutput: AVCaptureAudioDataOutput?
    private var backConnection: AVCaptureConnection?
    private var frontConnection: AVCaptureConnection?
    private var latestBackSample: CMSampleBuffer?
    private var latestFrontSample: CMSampleBuffer?
    private var pendingPhoto = false
    private var recordingMachine = RecordingStateMachine()
    private var observers: [NSObjectProtocol] = []

    override init() {
        super.init()
        recorder.onEvent = { [weak self] event in
            guard let self else { return }
            self.captureQueue.async {
                self.handleRecorderEvent(event)
            }
        }
        installNotifications()
    }

    deinit {
        observers.forEach(NotificationCenter.default.removeObserver)
        recorder.cancel()
        session?.stopRunning()
    }

    var outputAspectRatio: CGFloat {
        let size = orientation.outputSize
        return size.width / size.height
    }

    var pipRole: CameraRole { mainRole.opposite }

    func start() {
        guard availability == .unknown || !availability.isReady else { return }
        publish { self.availability = .requestingPermissions }

        Task { [weak self] in
            guard let self else { return }
            let permissionsGranted = await Self.requestRequiredPermissions()
            guard permissionsGranted else {
                self.publish {
                    self.availability = .failed(CaptureError.permissionsDenied.localizedDescription)
                }
                return
            }
            self.reloadLatestThumbnail()
            self.captureQueue.async {
                self.configureAndStartCapture()
            }
        }
    }

    func stop() {
        captureQueue.async {
            if self.recordingMachine.state.isBusy {
                _ = self.recordingMachine.handle(.requestStop)
                self.publishRecordingState()
                self.recorder.finish()
            }
            self.session?.stopRunning()
        }
    }

    func capturePhoto() {
        captureQueue.async {
            guard self.availability.isReady, !self.recordingMachine.state.isBusy else { return }
            self.pendingPhoto = true
            self.publish { self.notice = "正在拍照…" }
        }
    }

    func openPhotos() {
        guard let url = URL(string: "photos-redirect://") else { return }
        UIApplication.shared.open(url) { [weak self] success in
            if !success {
                self?.publish { self?.notice = "请打开系统“照片”App 查看 DualCam 相簿" }
            }
        }
    }

    func toggleRecording() {
        captureQueue.async {
            if self.recordingMachine.state.isBusy {
                _ = self.recordingMachine.handle(.requestStop)
                self.publishRecordingState()
                self.recorder.finish()
                return
            }
            guard self.availability.isReady else { return }
            do {
                let size = self.layoutStore.snapshot().orientation.outputSize
                try self.recorder.prepare(size: size)
                _ = self.recordingMachine.handle(.requestStart)
                self.publishRecordingState()
            } catch {
                _ = self.recordingMachine.handle(.fail(error.localizedDescription))
                self.publishRecordingState()
            }
        }
    }

    func setDisplayMode(_ mode: CameraDisplayMode) {
        guard mode == .back || dualCameraActive else { return }
        displayMode = mode
        switch mode {
        case .back:
            selectedRole = .back
        case .front:
            selectedRole = .front
        case .dual:
            selectedRole = mainRole
        }
        layoutStore.update(displayMode: mode)
        refreshControlState(for: selectedRole)
    }

    func swapMainCamera() {
        guard dualCameraActive, displayMode == .dual else { return }
        let newMain = mainRole.opposite
        mainRole = newMain
        selectedRole = newMain
        layoutStore.update(mainRole: newMain)
        refreshControlState(for: newMain)
    }

    func select(_ role: CameraRole) {
        guard role == .back || dualCameraActive else { return }
        selectedRole = role
        refreshControlState(for: role)
    }

    func movePiP(to point: CGPoint, in canvasSize: CGSize) {
        guard dualCameraActive, displayMode == .dual else { return }
        var updated = pipLayout
        updated.move(to: point, in: canvasSize)
        pipLayout = updated
        layoutStore.update(layout: updated)
    }

    func resizePiP(by scale: CGFloat, in canvasSize: CGSize) {
        guard dualCameraActive, displayMode == .dual else { return }
        var updated = pipLayout
        updated.resize(by: scale, in: canvasSize)
        pipLayout = updated
        layoutStore.update(layout: updated)
    }

    func updateOrientation(from deviceOrientation: UIDeviceOrientation) {
        let newOrientation: CaptureOrientation
        switch deviceOrientation {
        case .portrait: newOrientation = .portrait
        case .portraitUpsideDown: newOrientation = .portraitUpsideDown
        case .landscapeLeft: newOrientation = .landscapeLeft
        case .landscapeRight: newOrientation = .landscapeRight
        default: return
        }
        guard !recordingState.isBusy, newOrientation != orientation else { return }
        orientation = newOrientation
        layoutStore.update(orientation: newOrientation)
        captureQueue.async {
            self.applyRotation(newOrientation)
        }
    }

    func setZoom(_ value: CGFloat) {
        setDeviceConfiguration(for: selectedRole) { device in
            let upper = min(device.maxAvailableVideoZoomFactor, 10)
            device.videoZoomFactor = min(max(value, device.minAvailableVideoZoomFactor), upper)
        }
    }

    func setExposure(_ value: Float) {
        setDeviceConfiguration(for: selectedRole) { device in
            let value = min(max(value, device.minExposureTargetBias), device.maxExposureTargetBias)
            device.setExposureTargetBias(value, completionHandler: nil)
        }
    }

    func focus(at normalizedPoint: CGPoint, for role: CameraRole) {
        let point = role == .front
            ? CGPoint(x: 1 - normalizedPoint.x, y: normalizedPoint.y)
            : normalizedPoint
        setDeviceConfiguration(for: role) { device in
            if device.isFocusPointOfInterestSupported, device.isFocusModeSupported(.autoFocus) {
                device.focusPointOfInterest = point
                device.focusMode = .autoFocus
            }
            if device.isExposurePointOfInterestSupported, device.isExposureModeSupported(.continuousAutoExposure) {
                device.exposurePointOfInterest = point
                device.exposureMode = .continuousAutoExposure
            }
        }
    }

    func resetAutomaticControls() {
        setDeviceConfiguration(for: selectedRole) { device in
            if device.isFocusModeSupported(.continuousAutoFocus) {
                device.focusMode = .continuousAutoFocus
            }
            if device.isExposureModeSupported(.continuousAutoExposure) {
                device.exposureMode = .continuousAutoExposure
            }
            device.setExposureTargetBias(0, completionHandler: nil)
        }
    }

    // MARK: - Capture configuration

    private func configureAndStartCapture() {
        publish { self.availability = .configuring }
        do {
            let discovery = AVCaptureDevice.DiscoverySession(
                deviceTypes: [.builtInWideAngleCamera, .builtInTrueDepthCamera],
                mediaType: .video,
                position: .unspecified
            )
            guard let back = discovery.devices.first(where: { $0.position == .back }) else {
                throw CaptureError.cameraUnavailable
            }
            let front = discovery.devices.first(where: { $0.position == .front })
            let pairSupported = front.map { front in
                discovery.supportedMultiCamDeviceSets.contains { devices in
                    devices.contains(back) && devices.contains(front)
                }
            } ?? false
            let decision = CaptureSupport.decide(
                isMultiCamSupported: AVCaptureMultiCamSession.isMultiCamSupported,
                pairSupported: pairSupported
            )

            backDevice = back
            frontDevice = front
            try configureFormat(for: back, preferredHeight: 1080)

            let isDual: Bool
            let fallback: String?
            switch decision {
            case .dualCamera:
                guard let front else { throw CaptureError.cameraUnavailable }
                try configureFormat(for: front, preferredHeight: 1080)
                do {
                    try configureMultiCam(back: back, front: front)
                    isDual = true
                    fallback = nil
                } catch {
                    try configureSingleCamera(back: back)
                    isDual = false
                    fallback = "双摄配置未通过设备资源检查，已切换为后置单摄。"
                }
            case .singleCamera(let reason):
                try configureSingleCamera(back: back)
                isDual = false
                fallback = reason
            }

            applyRotation(layoutStore.snapshot().orientation)
            session?.startRunning()
            publish {
                self.dualCameraActive = isDual
                self.fallbackMessage = fallback
                self.displayMode = isDual ? .dual : .back
                self.availability = .ready(dualCamera: isDual)
            }
            layoutStore.update(displayMode: isDual ? .dual : .back)
            refreshControlState(for: .back)
        } catch {
            session?.stopRunning()
            publish {
                self.availability = .failed(error.localizedDescription)
            }
        }
    }

    private func configureMultiCam(back: AVCaptureDevice, front: AVCaptureDevice) throws {
        let session = AVCaptureMultiCamSession()
        session.beginConfiguration()
        defer { session.commitConfiguration() }

        let backInput = try AVCaptureDeviceInput(device: back)
        let frontInput = try AVCaptureDeviceInput(device: front)
        guard session.canAddInput(backInput), session.canAddInput(frontInput) else {
            throw CaptureError.configurationFailed("无法添加前后摄像头。")
        }
        session.addInputWithNoConnections(backInput)
        session.addInputWithNoConnections(frontInput)

        let backOutput = makeVideoOutput()
        let frontOutput = makeVideoOutput()
        guard session.canAddOutput(backOutput), session.canAddOutput(frontOutput) else {
            throw CaptureError.configurationFailed("无法添加双路视频输出。")
        }
        session.addOutputWithNoConnections(backOutput)
        session.addOutputWithNoConnections(frontOutput)

        guard
            let backPort = backInput.ports.first(where: { $0.mediaType == .video }),
            let frontPort = frontInput.ports.first(where: { $0.mediaType == .video })
        else { throw CaptureError.configurationFailed("找不到摄像头视频端口。") }

        let backConnection = AVCaptureConnection(inputPorts: [backPort], output: backOutput)
        let frontConnection = AVCaptureConnection(inputPorts: [frontPort], output: frontOutput)
        guard session.canAddConnection(backConnection), session.canAddConnection(frontConnection) else {
            throw CaptureError.configurationFailed("当前前后镜头组合超过设备资源限制。")
        }
        session.addConnection(backConnection)
        session.addConnection(frontConnection)
        configureFrontMirroring(frontConnection)

        let audioOutput = try addAudio(to: session, useExplicitConnections: true)
        audioOutput.setSampleBufferDelegate(self, queue: captureQueue)
        backOutput.setSampleBufferDelegate(self, queue: captureQueue)
        frontOutput.setSampleBufferDelegate(self, queue: captureQueue)

        self.session = session
        self.backOutput = backOutput
        self.frontOutput = frontOutput
        self.audioOutput = audioOutput
        self.backConnection = backConnection
        self.frontConnection = frontConnection
        self.latestBackSample = nil
        self.latestFrontSample = nil

        if session.hardwareCost > 1 {
            try configureFormat(for: back, preferredHeight: 720)
            try configureFormat(for: front, preferredHeight: 720)
        }
        if session.hardwareCost > 1 {
            throw CaptureError.configurationFailed("即使降低到 720p，双摄仍超过硬件预算。")
        }
    }

    private func configureSingleCamera(back: AVCaptureDevice) throws {
        let session = AVCaptureSession()
        session.beginConfiguration()
        defer { session.commitConfiguration() }
        session.sessionPreset = .hd1920x1080

        let backInput = try AVCaptureDeviceInput(device: back)
        let backOutput = makeVideoOutput()
        guard session.canAddInput(backInput), session.canAddOutput(backOutput) else {
            throw CaptureError.configurationFailed("无法添加后置摄像头。")
        }
        session.addInput(backInput)
        session.addOutput(backOutput)
        backOutput.setSampleBufferDelegate(self, queue: captureQueue)

        let audioOutput = try addAudio(to: session, useExplicitConnections: false)
        audioOutput.setSampleBufferDelegate(self, queue: captureQueue)

        self.session = session
        self.backOutput = backOutput
        self.frontOutput = nil
        self.audioOutput = audioOutput
        self.backConnection = backOutput.connection(with: .video)
        self.frontConnection = nil
        self.latestBackSample = nil
        self.latestFrontSample = nil
    }

    private func makeVideoOutput() -> AVCaptureVideoDataOutput {
        let output = AVCaptureVideoDataOutput()
        output.alwaysDiscardsLateVideoFrames = true
        output.videoSettings = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA
        ]
        return output
    }

    private func addAudio(to session: AVCaptureSession, useExplicitConnections: Bool) throws -> AVCaptureAudioDataOutput {
        guard let microphone = AVCaptureDevice.default(for: .audio) else {
            throw CaptureError.configurationFailed("找不到麦克风。")
        }
        let input = try AVCaptureDeviceInput(device: microphone)
        let output = AVCaptureAudioDataOutput()
        guard session.canAddInput(input), session.canAddOutput(output) else {
            throw CaptureError.configurationFailed("无法添加麦克风。")
        }
        if useExplicitConnections, let multiCam = session as? AVCaptureMultiCamSession {
            multiCam.addInputWithNoConnections(input)
            multiCam.addOutputWithNoConnections(output)
            guard let port = input.ports.first(where: { $0.mediaType == .audio }) else {
                throw CaptureError.configurationFailed("找不到麦克风音频端口。")
            }
            let connection = AVCaptureConnection(inputPorts: [port], output: output)
            guard multiCam.canAddConnection(connection) else {
                throw CaptureError.configurationFailed("无法连接麦克风。")
            }
            multiCam.addConnection(connection)
        } else {
            session.addInput(input)
            session.addOutput(output)
        }
        return output
    }

    private func configureFormat(for device: AVCaptureDevice, preferredHeight: Int32) throws {
        let desiredRate = 30.0
        let candidates = device.formats.filter { format in
            let dimensions = CMVideoFormatDescriptionGetDimensions(format.formatDescription)
            let matchesSize = dimensions.width == preferredHeight * 16 / 9 && dimensions.height == preferredHeight
            let supportsRate = format.videoSupportedFrameRateRanges.contains {
                $0.minFrameRate <= desiredRate && $0.maxFrameRate >= desiredRate
            }
            return matchesSize && supportsRate
        }
        guard let format = candidates.first else { return }
        try device.lockForConfiguration()
        device.activeFormat = format
        device.activeVideoMinFrameDuration = CMTime(value: 1, timescale: 30)
        device.activeVideoMaxFrameDuration = CMTime(value: 1, timescale: 30)
        device.unlockForConfiguration()
    }

    private func applyRotation(_ orientation: CaptureOrientation) {
        [backConnection, frontConnection].forEach { connection in
            guard let connection, connection.isVideoRotationAngleSupported(orientation.rotationAngle) else { return }
            connection.videoRotationAngle = orientation.rotationAngle
        }
        if let frontConnection { configureFrontMirroring(frontConnection) }
    }

    private func configureFrontMirroring(_ connection: AVCaptureConnection) {
        guard connection.isVideoMirroringSupported else { return }
        connection.automaticallyAdjustsVideoMirroring = false
        connection.isVideoMirrored = true
    }

    // MARK: - Frame handling

    private func handleVideoArrival(_ sampleBuffer: CMSampleBuffer, role: CameraRole) {
        if role == .back {
            latestBackSample = sampleBuffer
        } else {
            latestFrontSample = sampleBuffer
        }

        let snapshot = layoutStore.snapshot()
        guard FrameRenderPolicy.shouldRender(
            mode: snapshot.displayMode,
            arrival: role,
            hasBackFrame: latestBackSample != nil,
            hasFrontFrame: latestFrontSample != nil
        ) else { return }

        let backBuffer = latestBackSample.flatMap(CMSampleBufferGetImageBuffer)
        let frontBuffer = latestFrontSample.flatMap(CMSampleBufferGetImageBuffer)
        do {
            let composed = try compositor.compose(
                backBuffer: backBuffer,
                frontBuffer: frontBuffer,
                snapshot: snapshot
            )
            previewStore.update(composed)

            if pendingPhoto {
                pendingPhoto = false
                savePhoto(from: composed)
            }
            if recorder.isPrepared {
                recorder.appendVideo(composed, at: CMSampleBufferGetPresentationTimeStamp(sampleBuffer))
            }
        } catch {
            publish { self.notice = error.localizedDescription }
        }
    }

    private func handleRecorderEvent(_ event: VideoRecorder.Event) {
        switch event {
        case .started(let date):
            _ = recordingMachine.handle(.firstFrame(date))
            publishRecordingState()
        case .finished(.success(let url)):
            saveVideo(at: url)
        case .finished(.failure(let error)):
            _ = recordingMachine.handle(.fail(error.localizedDescription))
            publishRecordingState()
        }
    }

    private func savePhoto(from pixelBuffer: CVPixelBuffer) {
        do {
            let cgImage = try compositor.makeCGImage(from: pixelBuffer)
            let image = UIImage(cgImage: cgImage)
            PhotoLibrarySaver.save(image: image) { [weak self] success, error in
                if success { self?.reloadLatestThumbnail() }
                self?.publish {
                    self?.notice = success
                        ? "已保存：照片 App → 相簿 → DualCam"
                        : CaptureError.saveFailed(error?.localizedDescription ?? "未知错误").localizedDescription
                }
            }
        } catch {
            publish { self.notice = CaptureError.saveFailed(error.localizedDescription).localizedDescription }
        }
    }

    private func saveVideo(at url: URL) {
        PhotoLibrarySaver.saveVideo(at: url) { [weak self] success, error in
            guard let self else { return }
            self.captureQueue.async {
                try? FileManager.default.removeItem(at: url)
                if success {
                    self.reloadLatestThumbnail()
                    _ = self.recordingMachine.handle(.finish)
                    self.publishRecordingState()
                    self.publish { self.notice = "已保存：照片 App → 相簿 → DualCam" }
                } else {
                    _ = self.recordingMachine.handle(.fail(error?.localizedDescription ?? "未知错误"))
                    self.publishRecordingState()
                }
            }
        }
    }

    // MARK: - Controls and lifecycle

    private func reloadLatestThumbnail() {
        PhotoLibrarySaver.loadLatestThumbnail { [weak self] image in
            self?.publish { self?.latestThumbnail = image }
        }
    }

    private func setDeviceConfiguration(for role: CameraRole, change: @escaping (AVCaptureDevice) -> Void) {
        captureQueue.async {
            guard let device = role == .back ? self.backDevice : self.frontDevice else { return }
            do {
                try device.lockForConfiguration()
                change(device)
                device.unlockForConfiguration()
                self.refreshControlState(for: role)
            } catch {
                self.publish { self.notice = "参数调整失败：\(error.localizedDescription)" }
            }
        }
    }

    private func refreshControlState(for role: CameraRole) {
        captureQueue.async {
            guard let device = role == .back ? self.backDevice : self.frontDevice else { return }
            let state = CameraControlState(
                zoom: device.videoZoomFactor,
                zoomRange: device.minAvailableVideoZoomFactor...min(device.maxAvailableVideoZoomFactor, 10),
                exposure: device.exposureTargetBias,
                exposureRange: device.minExposureTargetBias...device.maxExposureTargetBias
            )
            self.publish {
                if self.selectedRole == role { self.controlState = state }
            }
        }
    }

    private func installNotifications() {
        let center = NotificationCenter.default
        observers.append(center.addObserver(
            forName: .AVCaptureSessionWasInterrupted,
            object: nil,
            queue: nil
        ) { [weak self] notification in
            self?.captureQueue.async { self?.handleInterruption(notification) }
        })
        observers.append(center.addObserver(
            forName: .AVCaptureSessionInterruptionEnded,
            object: nil,
            queue: nil
        ) { [weak self] _ in
            self?.captureQueue.async {
                guard let self else { return }
                if let session = self.session, !session.isRunning { session.startRunning() }
                let dual = self.dualCameraActive
                self.publish { self.availability = .ready(dualCamera: dual) }
            }
        })
        observers.append(center.addObserver(
            forName: .AVCaptureSessionRuntimeError,
            object: nil,
            queue: nil
        ) { [weak self] notification in
            let message = (notification.userInfo?[AVCaptureSessionErrorKey] as? Error)?.localizedDescription ?? "未知错误"
            self?.publish { self?.availability = .failed("相机运行错误：\(message)") }
        })
        observers.append(center.addObserver(
            forName: UIApplication.didEnterBackgroundNotification,
            object: nil,
            queue: nil
        ) { [weak self] _ in
            self?.captureQueue.async { self?.finishRecordingForInterruption("应用进入后台，录像已安全结束。") }
        })
    }

    private func handleInterruption(_ notification: Notification) {
        let rawReason = (notification.userInfo?[AVCaptureSessionInterruptionReasonKey] as? NSNumber)?.intValue
        let reason = rawReason.flatMap(AVCaptureSession.InterruptionReason.init(rawValue:))
        let message: String
        switch reason {
        case .videoDeviceNotAvailableDueToSystemPressure:
            message = "设备温度或系统压力过高，双摄已暂停。"
        case .videoDeviceInUseByAnotherClient:
            message = "摄像头正被其他应用使用。"
        default:
            message = "拍摄被系统暂时中断。"
        }
        finishRecordingForInterruption(message)
        publish { self.availability = .interrupted(message) }
    }

    private func finishRecordingForInterruption(_ message: String) {
        guard recordingMachine.state.isBusy else { return }
        _ = recordingMachine.handle(.requestStop)
        publishRecordingState()
        publish { self.notice = message }
        recorder.finish()
    }

    private func publishRecordingState() {
        let state = recordingMachine.state
        publish { self.recordingState = state }
    }

    private func publish(_ change: @escaping () -> Void) {
        if Thread.isMainThread {
            change()
        } else {
            DispatchQueue.main.async(execute: change)
        }
    }

    private static func requestRequiredPermissions() async -> Bool {
        let camera = await requestAccess(for: .video)
        let microphone = await requestAccess(for: .audio)
        let photos = await requestPhotoAccess()
        return camera && microphone && photos
    }

    private static func requestAccess(for mediaType: AVMediaType) async -> Bool {
        switch AVCaptureDevice.authorizationStatus(for: mediaType) {
        case .authorized: return true
        case .denied, .restricted: return false
        case .notDetermined:
            return await withCheckedContinuation { continuation in
                AVCaptureDevice.requestAccess(for: mediaType) { granted in
                    continuation.resume(returning: granted)
                }
            }
        @unknown default: return false
        }
    }

    private static func requestPhotoAccess() async -> Bool {
        switch PHPhotoLibrary.authorizationStatus(for: .readWrite) {
        case .authorized, .limited: return true
        case .denied, .restricted: return false
        case .notDetermined:
            return await withCheckedContinuation { continuation in
                PHPhotoLibrary.requestAuthorization(for: .readWrite) { status in
                    continuation.resume(returning: status == .authorized || status == .limited)
                }
            }
        @unknown default: return false
        }
    }
}

extension DualCameraController: AVCaptureVideoDataOutputSampleBufferDelegate, AVCaptureAudioDataOutputSampleBufferDelegate {
    func captureOutput(
        _ output: AVCaptureOutput,
        didOutput sampleBuffer: CMSampleBuffer,
        from connection: AVCaptureConnection
    ) {
        if output === audioOutput {
            if recorder.isPrepared { recorder.appendAudio(sampleBuffer) }
        } else if output === backOutput {
            handleVideoArrival(sampleBuffer, role: .back)
        } else if output === frontOutput {
            handleVideoArrival(sampleBuffer, role: .front)
        }
    }
}
