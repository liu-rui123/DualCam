import SwiftUI
import UIKit

struct CameraScreen: View {
    @StateObject private var controller = DualCameraController()
    @State private var lastMagnification: CGFloat = 1
    @State private var draggingPiP = false
    @State private var showProfessionalSettings = false
    @State private var focusIndicatorPoint: CGPoint?
    @State private var focusIndicatorToken = UUID()

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            cameraCanvas
                .ignoresSafeArea()

            VStack(spacing: 0) {
                statusBar
                Spacer()
                controls
            }

            if let notice = controller.notice {
                VStack {
                    Spacer()
                    Text(notice)
                        .font(.subheadline.weight(.medium))
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(.ultraThinMaterial, in: Capsule())
                        .padding(.bottom, 230)
                }
                .transition(.opacity)
                .allowsHitTesting(false)
            }

            blockingStatusOverlay
        }
        .onAppear {
            UIDevice.current.beginGeneratingDeviceOrientationNotifications()
            controller.updateOrientation(from: UIDevice.current.orientation)
            controller.start()
        }
        .onDisappear {
            UIDevice.current.endGeneratingDeviceOrientationNotifications()
            controller.stop()
        }
        .onReceive(NotificationCenter.default.publisher(for: UIDevice.orientationDidChangeNotification)) { _ in
            controller.updateOrientation(from: UIDevice.current.orientation)
        }
        .onChange(of: controller.notice) { _, newValue in
            guard let newValue else { return }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                if controller.notice == newValue {
                    controller.notice = nil
                }
            }
        }
        .sheet(isPresented: $showProfessionalSettings) {
            ProfessionalSettingsView(controller: controller)
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
                .presentationBackground(.ultraThinMaterial)
        }
    }

    private var statusBar: some View {
        VStack(spacing: 4) {
            HStack {
                Label(
                    controller.displayMode.title,
                    systemImage: controller.displayMode.symbolName
                )
                .font(.caption.weight(.semibold))

                Spacer()

                if controller.recordingState.isBusy {
                    HStack(spacing: 10) {
                        Label(formatDuration(controller.recordingElapsed), systemImage: "record.circle.fill")
                            .foregroundStyle(.red)
                        Label(controller.availableStorageText, systemImage: "internaldrive")
                        Image(systemName: controller.isMicrophoneEnabled ? "mic.fill" : "mic.slash.fill")
                            .foregroundStyle(controller.isMicrophoneEnabled ? Color.white : Color.yellow)
                    }
                    .font(.caption.weight(.semibold).monospacedDigit())
                }
            }

            if let message = controller.fallbackMessage {
                Text(message)
                    .font(.caption2)
                    .foregroundStyle(.yellow)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
        // Keep camera pixels out of the header visually. A translucent header
        // looked like a dark strip covering the top of the captured scene.
        .background(Color.black)
    }

    private var cameraCanvas: some View {
        GeometryReader { proxy in
            let canvasSize = fittedSize(
                aspectRatio: controller.outputAspectRatio,
                inside: proxy.size
            )
            let pipRect = controller.pipLayout.rect(in: canvasSize)

            ZStack(alignment: .topLeading) {
                MetalPreviewView(store: controller.previewStore)
                    .frame(width: canvasSize.width, height: canvasSize.height)
                    .contentShape(Rectangle())

                if controller.dualCameraActive,
                   controller.displayMode == .dual,
                   controller.selectedRole == controller.pipRole {
                    let cornerRadius = max(10, pipRect.width * 0.08)

                    RoundedRectangle(cornerRadius: cornerRadius)
                        .strokeBorder(
                            LinearGradient(
                                colors: [
                                    Color(red: 1.0, green: 0.93, blue: 0.28),
                                    Color(red: 1.0, green: 0.64, blue: 0.02)
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 3
                        )
                        .frame(width: pipRect.width, height: pipRect.height)
                        .position(x: pipRect.midX, y: pipRect.midY)
                        .shadow(color: Color.yellow.opacity(0.75), radius: 7)
                        .allowsHitTesting(false)

                    HStack(spacing: 5) {
                        Circle()
                            .fill(Color.yellow)
                            .frame(width: 6, height: 6)
                        Text("\(controller.pipRole.title)参数")
                            .font(.system(size: 11, weight: .semibold))
                    }
                    .foregroundStyle(.white)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 5)
                    .background(Color.black.opacity(0.72), in: Capsule())
                    .overlay(Capsule().stroke(Color.yellow.opacity(0.7), lineWidth: 0.8))
                    .position(x: pipRect.midX, y: pipRect.minY + 18)
                    .allowsHitTesting(false)
                }

                if let focusIndicatorPoint {
                    RoundedRectangle(cornerRadius: 5)
                        .stroke(Color.yellow, lineWidth: 2)
                        .frame(width: 68, height: 68)
                        .position(focusIndicatorPoint)
                        .transition(.scale.combined(with: .opacity))
                        .allowsHitTesting(false)
                }

            }
            .frame(width: canvasSize.width, height: canvasSize.height)
            .position(x: proxy.size.width / 2, y: proxy.size.height / 2)
            .simultaneousGesture(
                SpatialTapGesture().onEnded { value in
                    handleTap(at: value.location, canvasSize: canvasSize)
                }
            )
            .simultaneousGesture(
                DragGesture(minimumDistance: 4, coordinateSpace: .local)
                    .onChanged { value in
                        if !draggingPiP {
                            draggingPiP = controller.dualCameraActive
                                && controller.displayMode == .dual
                                && pipRect.contains(value.startLocation)
                        }
                        if draggingPiP {
                            controller.movePiP(to: value.location, in: canvasSize)
                        }
                    }
                    .onEnded { _ in draggingPiP = false }
            )
            .simultaneousGesture(
                MagnificationGesture()
                    .onChanged { value in
                        guard controller.dualCameraActive, controller.displayMode == .dual else { return }
                        let incremental = value / lastMagnification
                        controller.resizePiP(by: incremental, in: canvasSize)
                        lastMagnification = value
                    }
                    .onEnded { _ in lastMagnification = 1 }
            )
            .simultaneousGesture(
                LongPressGesture(minimumDuration: 0.65)
                    .onEnded { _ in controller.toggleFocusExposureLock() }
            )
        }
    }

    private var controls: some View {
        VStack(spacing: 12) {
            cameraModeSelector
            compactParameterBar

            Picker("拍摄模式", selection: $controller.captureMode) {
                ForEach(CaptureMode.allCases, id: \.self) { mode in
                    Text(mode.title).tag(mode)
                }
            }
            .pickerStyle(.segmented)
            .disabled(controller.recordingState.isBusy)

            HStack(spacing: 42) {
                Button {
                    controller.openPhotos()
                } label: {
                    Group {
                        if let thumbnail = controller.latestThumbnail {
                            Image(uiImage: thumbnail)
                                .resizable()
                                .scaledToFill()
                        } else {
                            Image(systemName: "photo")
                                .font(.title2)
                                .foregroundStyle(.white)
                        }
                    }
                    .frame(width: 48, height: 48)
                    .background(Color.white.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(.white.opacity(0.7), lineWidth: 1))
                }
                .accessibilityLabel("打开照片查看最近成片")

                Button {
                    if controller.captureMode == .photo {
                        controller.capturePhoto()
                    } else {
                        controller.toggleRecording()
                    }
                } label: {
                    ZStack {
                        Circle()
                            .stroke(.white, lineWidth: 4)
                            .frame(width: 72, height: 72)
                        if controller.captureMode == .photo {
                            Circle().fill(.white).frame(width: 60, height: 60)
                        } else {
                            RoundedRectangle(cornerRadius: controller.recordingState.isBusy ? 7 : 28)
                                .fill(.red)
                                .frame(
                                    width: controller.recordingState.isBusy ? 30 : 56,
                                    height: controller.recordingState.isBusy ? 30 : 56
                                )
                        }
                    }
                }
                .disabled(!controller.availability.isReady || controller.recordingState == .finishing)
                .accessibilityLabel(controller.captureMode == .photo ? "拍照" : "开始或停止录像")

                Button {
                    if controller.displayMode == .dual {
                        controller.swapMainCamera()
                    } else {
                        controller.resetAutomaticControls()
                    }
                } label: {
                    Image(systemName: controller.displayMode == .dual
                        ? "arrow.triangle.2.circlepath.camera"
                        : "a.circle")
                        .font(.title2)
                        .frame(width: 48, height: 48)
                }
                .accessibilityLabel(controller.displayMode == .dual ? "切换前后画面主次" : "恢复自动参数")
            }
        }
        .padding(.horizontal, 18)
        .padding(.top, 10)
        .padding(.bottom, 8)
        .background(Color.black.opacity(0.78))
    }

    private var cameraModeSelector: some View {
        HStack(spacing: 8) {
            ForEach(CameraDisplayMode.allCases, id: \.self) { mode in
                Button {
                    controller.setDisplayMode(mode)
                } label: {
                    Label(mode.title, systemImage: mode.symbolName)
                        .font(.caption.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 7)
                        .background(
                            controller.displayMode == mode ? Color.yellow : Color.white.opacity(0.12),
                            in: Capsule()
                        )
                        .foregroundStyle(controller.displayMode == mode ? Color.black : Color.white)
                }
                .disabled(mode != .back && !controller.dualCameraActive)
            }
        }
    }

    private var compactParameterBar: some View {
        HStack(spacing: 14) {
            Text("当前：\(controller.selectedRole.title)")
                .font(.caption.weight(.semibold))
            if controller.controlState.isFocusExposureLocked {
                Label("AE/AF 锁定", systemImage: "lock.fill")
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(.yellow)
            }
            Spacer()
            Button {
                showProfessionalSettings = true
            } label: {
                Label("专业设置", systemImage: "slider.horizontal.3")
            }
            Text(String(format: "%.1f×", controller.controlState.zoom))
                .monospacedDigit()
        }
        .font(.caption.weight(.semibold))
    }

    @ViewBuilder
    private var blockingStatusOverlay: some View {
        switch controller.availability {
        case .unknown, .requestingPermissions, .configuring:
            ZStack {
                Color.black.opacity(0.72).ignoresSafeArea()
                ProgressView(statusText)
                    .tint(.white)
            }
        case .failed(let message):
            ZStack {
                Color.black.opacity(0.86).ignoresSafeArea()
                VStack(spacing: 16) {
                    Image(systemName: "camera.badge.ellipsis")
                        .font(.system(size: 42))
                    Text(message)
                        .multilineTextAlignment(.center)
                    Button("打开系统设置") {
                        guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
                        UIApplication.shared.open(url)
                    }
                    .buttonStyle(.borderedProminent)
                }
                .padding(30)
            }
        case .interrupted(let message):
            ZStack {
                Color.black.opacity(0.72).ignoresSafeArea()
                Text(message).multilineTextAlignment(.center).padding(30)
            }
        case .ready:
            EmptyView()
        }
    }

    private var statusText: String {
        switch controller.availability {
        case .requestingPermissions: return "正在请求权限…"
        case .configuring: return "正在启动双摄…"
        default: return "正在准备相机…"
        }
    }

    private func handleTap(at point: CGPoint, canvasSize: CGSize) {
        let pipRect = controller.pipLayout.rect(in: canvasSize)
        let role: CameraRole
        let normalized: CGPoint
        if controller.dualCameraActive,
           controller.displayMode == .dual,
           pipRect.contains(point) {
            role = controller.pipRole
            normalized = CGPoint(
                x: (point.x - pipRect.minX) / pipRect.width,
                y: (point.y - pipRect.minY) / pipRect.height
            )
        } else {
            switch controller.displayMode {
            case .back: role = .back
            case .front: role = .front
            case .dual: role = controller.mainRole
            }
            normalized = CGPoint(x: point.x / canvasSize.width, y: point.y / canvasSize.height)
        }
        controller.select(role)
        controller.focus(at: normalized, for: role)
        showFocusIndicator(at: point)
    }

    private func showFocusIndicator(at point: CGPoint) {
        let token = UUID()
        focusIndicatorToken = token
        withAnimation(.spring(response: 0.22, dampingFraction: 0.72)) {
            focusIndicatorPoint = point
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.1) {
            guard focusIndicatorToken == token else { return }
            withAnimation(.easeOut(duration: 0.25)) {
                focusIndicatorPoint = nil
            }
        }
    }

    private func fittedSize(aspectRatio: CGFloat, inside container: CGSize) -> CGSize {
        guard aspectRatio > 0, container.width > 0, container.height > 0 else { return .zero }
        let containerAspect = container.width / container.height
        if containerAspect > aspectRatio {
            return CGSize(width: container.height * aspectRatio, height: container.height)
        }
        return CGSize(width: container.width, height: container.width / aspectRatio)
    }

    private func formatDuration(_ interval: TimeInterval) -> String {
        let seconds = max(0, Int(interval))
        return String(format: "%02d:%02d", seconds / 60, seconds % 60)
    }
}

private struct ProfessionalSettingsView: View {
    @ObservedObject var controller: DualCameraController
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section("当前镜头 · \(controller.selectedRole.title)") {
                    Button {
                        controller.toggleFocusExposureLock()
                    } label: {
                        Label(
                            controller.controlState.isFocusExposureLocked ? "解除 AE/AF 锁定" : "锁定当前 AE/AF",
                            systemImage: controller.controlState.isFocusExposureLocked ? "lock.open" : "lock"
                        )
                    }

                    Button("全部恢复自动") {
                        controller.resetAutomaticControls()
                    }
                }

                Section("基础参数") {
                    parameterRow(
                        title: "变焦",
                        value: String(format: "%.1f×", controller.controlState.zoom)
                    ) {
                        Slider(
                            value: Binding(
                                get: { Double(controller.controlState.zoom) },
                                set: { controller.setZoom(CGFloat($0)) }
                            ),
                            in: safeRange(controller.controlState.zoomRange)
                        )
                    }

                    parameterRow(
                        title: "曝光补偿",
                        value: String(format: "%+.1f", controller.controlState.exposure)
                    ) {
                        Slider(
                            value: Binding(
                                get: { Double(controller.controlState.exposure) },
                                set: { controller.setExposure(Float($0)) }
                            ),
                            in: safeRange(controller.controlState.exposureRange)
                        )
                    }
                }

                Section("手动曝光") {
                    parameterRow(
                        title: "ISO",
                        value: String(format: "%.0f", controller.controlState.iso)
                    ) {
                        Slider(
                            value: Binding(
                                get: { Double(controller.controlState.iso) },
                                set: { controller.setISO(Float($0)) }
                            ),
                            in: safeRange(controller.controlState.isoRange)
                        )
                    }

                    parameterRow(
                        title: "快门",
                        value: shutterLabel(controller.controlState.shutterDuration)
                    ) {
                        Slider(
                            value: Binding(
                                get: { log10(max(controller.controlState.shutterDuration, 0.000_001)) },
                                set: { controller.setShutterDuration(pow(10, $0)) }
                            ),
                            in: shutterLogRange
                        )
                    }
                }

                Section("白平衡") {
                    parameterRow(
                        title: "色温",
                        value: "\(Int(controller.controlState.whiteBalanceTemperature))K"
                    ) {
                        Slider(
                            value: Binding(
                                get: { Double(controller.controlState.whiteBalanceTemperature) },
                                set: {
                                    controller.setWhiteBalance(
                                        temperature: Float($0),
                                        tint: controller.controlState.whiteBalanceTint
                                    )
                                }
                            ),
                            in: 2_500...10_000
                        )
                    }

                    parameterRow(
                        title: "色调",
                        value: String(format: "%+.0f", controller.controlState.whiteBalanceTint)
                    ) {
                        Slider(
                            value: Binding(
                                get: { Double(controller.controlState.whiteBalanceTint) },
                                set: {
                                    controller.setWhiteBalance(
                                        temperature: controller.controlState.whiteBalanceTemperature,
                                        tint: Float($0)
                                    )
                                }
                            ),
                            in: -150...150
                        )
                    }
                }

                Section("成片效果") {
                    Picker(
                        "滤镜",
                        selection: Binding(
                            get: { controller.selectedFilter },
                            set: { controller.setFilter($0) }
                        )
                    ) {
                        ForEach(CameraFilter.allCases, id: \.self) { filter in
                            Text(filter.title).tag(filter)
                        }
                    }

                    Toggle(
                        "日期时间水印",
                        isOn: Binding(
                            get: { controller.isDateWatermarkEnabled },
                            set: { controller.setDateWatermarkEnabled($0) }
                        )
                    )
                }

                Section("录像") {
                    Toggle(
                        "录制麦克风声音",
                        isOn: Binding(
                            get: { controller.isMicrophoneEnabled },
                            set: { controller.setMicrophoneEnabled($0) }
                        )
                    )
                    LabeledContent("设备可用空间", value: controller.availableStorageText)
                }
            }
            .navigationTitle("专业设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { dismiss() }
                }
            }
        }
    }

    @ViewBuilder
    private func parameterRow<Content: View>(
        title: String,
        value: String,
        @ViewBuilder content: () -> Content
    ) -> some View {
        VStack(spacing: 6) {
            HStack {
                Text(title)
                Spacer()
                Text(value)
                    .foregroundStyle(.secondary)
                    .monospacedDigit()
            }
            content()
        }
    }

    private var shutterLogRange: ClosedRange<Double> {
        let minimum = max(controller.controlState.shutterRange.lowerBound, 0.000_001)
        let maximum = max(controller.controlState.shutterRange.upperBound, minimum)
        let lower = log10(minimum)
        let upper = log10(maximum)
        return lower < upper ? lower...upper : lower...(lower + 0.001)
    }

    private func safeRange<T: BinaryFloatingPoint>(_ range: ClosedRange<T>) -> ClosedRange<Double> {
        let lower = Double(range.lowerBound)
        let upper = Double(range.upperBound)
        return lower < upper ? lower...upper : lower...(lower + 0.001)
    }

    private func shutterLabel(_ seconds: Double) -> String {
        guard seconds > 0 else { return "--" }
        if seconds >= 1 { return String(format: "%.1fs", seconds) }
        return "1/\(max(1, Int((1 / seconds).rounded())))"
    }
}

#Preview {
    CameraScreen()
}
