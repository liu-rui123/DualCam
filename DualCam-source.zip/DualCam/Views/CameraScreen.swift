import SwiftUI
import UIKit

struct CameraScreen: View {
    @StateObject private var controller = DualCameraController()
    @State private var lastMagnification: CGFloat = 1
    @State private var draggingPiP = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 0) {
                statusBar
                cameraCanvas
                controls
            }

            if let notice = controller.notice {
                VStack {
                    Spacer()
                    Text(notice)
                        .font(.subheadline.weight(.medium))
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(.ultraThinMaterial, in: Capsule())
                        .padding(.bottom, 190)
                }
                .transition(.opacity)
                .allowsHitTesting(false)
            }

            blockingStatusOverlay
        }
        .onAppear {
            UIDevice.current.beginGeneratingDeviceOrientationNotifications()
            controller.updateOrientation(from: UIDevice.current.orientation)
            controller.start()
        }
        .onDisappear {
            UIDevice.current.endGeneratingDeviceOrientationNotifications()
            controller.stop()
        }
        .onReceive(NotificationCenter.default.publisher(for: UIDevice.orientationDidChangeNotification)) { _ in
            controller.updateOrientation(from: UIDevice.current.orientation)
        }
        .onChange(of: controller.notice) { _, newValue in
            guard let newValue else { return }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                if controller.notice == newValue {
                    controller.notice = nil
                }
            }
        }
    }

    private var statusBar: some View {
        VStack(spacing: 4) {
            HStack {
                Label(
                    controller.dualCameraActive ? "前后双摄" : "后置单摄",
                    systemImage: controller.dualCameraActive ? "rectangle.on.rectangle" : "camera"
                )
                .font(.caption.weight(.semibold))

                Spacer()

                if controller.recordingState.isRecording {
                    Label("录制中", systemImage: "record.circle.fill")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.red)
                }
            }

            if let message = controller.fallbackMessage {
                Text(message)
                    .font(.caption2)
                    .foregroundStyle(.yellow)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
        .background(Color.black.opacity(0.92))
    }

    private var cameraCanvas: some View {
        GeometryReader { proxy in
            let canvasSize = fittedSize(
                aspectRatio: controller.outputAspectRatio,
                inside: proxy.size
            )
            let pipRect = controller.pipLayout.rect(in: canvasSize)

            ZStack(alignment: .topLeading) {
                MetalPreviewView(store: controller.previewStore)
                    .frame(width: canvasSize.width, height: canvasSize.height)
                    .contentShape(Rectangle())

                if controller.dualCameraActive {
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(
                            controller.selectedRole == controller.pipRole ? Color.yellow : Color.white,
                            lineWidth: controller.selectedRole == controller.pipRole ? 4 : 2
                        )
                        .frame(width: pipRect.width, height: pipRect.height)
                        .position(x: pipRect.midX, y: pipRect.midY)
                        .allowsHitTesting(false)
                }

                if controller.selectedRole == controller.mainRole {
                    Rectangle()
                        .stroke(Color.yellow.opacity(0.7), lineWidth: 2)
                        .frame(width: canvasSize.width, height: canvasSize.height)
                        .allowsHitTesting(false)
                }
            }
            .frame(width: canvasSize.width, height: canvasSize.height)
            .position(x: proxy.size.width / 2, y: proxy.size.height / 2)
            .simultaneousGesture(
                SpatialTapGesture().onEnded { value in
                    handleTap(at: value.location, canvasSize: canvasSize)
                }
            )
            .simultaneousGesture(
                DragGesture(minimumDistance: 4, coordinateSpace: .local)
                    .onChanged { value in
                        if !draggingPiP {
                            draggingPiP = controller.dualCameraActive && pipRect.contains(value.startLocation)
                        }
                        if draggingPiP {
                            controller.movePiP(to: value.location, in: canvasSize)
                        }
                    }
                    .onEnded { _ in draggingPiP = false }
            )
            .simultaneousGesture(
                MagnificationGesture()
                    .onChanged { value in
                        guard controller.dualCameraActive else { return }
                        let incremental = value / lastMagnification
                        controller.resizePiP(by: incremental, in: canvasSize)
                        lastMagnification = value
                    }
                    .onEnded { _ in lastMagnification = 1 }
            )
        }
    }

    private var controls: some View {
        VStack(spacing: 12) {
            parameterControls

            Picker("拍摄模式", selection: $controller.captureMode) {
                ForEach(CaptureMode.allCases, id: \.self) { mode in
                    Text(mode.title).tag(mode)
                }
            }
            .pickerStyle(.segmented)
            .disabled(controller.recordingState.isBusy)

            HStack(spacing: 42) {
                Button {
                    controller.swapMainCamera()
                } label: {
                    Image(systemName: "arrow.triangle.2.circlepath.camera")
                        .font(.title2)
                        .frame(width: 48, height: 48)
                }
                .disabled(!controller.dualCameraActive)
                .accessibilityLabel("切换前后画面主次")

                Button {
                    if controller.captureMode == .photo {
                        controller.capturePhoto()
                    } else {
                        controller.toggleRecording()
                    }
                } label: {
                    ZStack {
                        Circle()
                            .stroke(.white, lineWidth: 4)
                            .frame(width: 72, height: 72)
                        if controller.captureMode == .photo {
                            Circle().fill(.white).frame(width: 60, height: 60)
                        } else {
                            RoundedRectangle(cornerRadius: controller.recordingState.isBusy ? 7 : 28)
                                .fill(.red)
                                .frame(
                                    width: controller.recordingState.isBusy ? 30 : 56,
                                    height: controller.recordingState.isBusy ? 30 : 56
                                )
                        }
                    }
                }
                .disabled(!controller.availability.isReady || controller.recordingState == .finishing)
                .accessibilityLabel(controller.captureMode == .photo ? "拍照" : "开始或停止录像")

                Button {
                    controller.resetAutomaticControls()
                } label: {
                    Image(systemName: "a.circle")
                        .font(.title2)
                        .frame(width: 48, height: 48)
                }
                .accessibilityLabel("恢复自动参数")
            }
        }
        .padding(.horizontal, 18)
        .padding(.top, 10)
        .padding(.bottom, 8)
        .background(Color.black.opacity(0.95))
    }

    private var parameterControls: some View {
        VStack(spacing: 8) {
            HStack {
                Text("当前：\(controller.selectedRole.title)")
                    .font(.caption.weight(.semibold))
                Spacer()
                Text(String(format: "%.1f×", controller.controlState.zoom))
                    .font(.caption.monospacedDigit())
            }

            HStack {
                Image(systemName: "plus.magnifyingglass")
                Slider(
                    value: Binding(
                        get: { Double(controller.controlState.zoom) },
                        set: { controller.setZoom(CGFloat($0)) }
                    ),
                    in: safeRange(controller.controlState.zoomRange)
                )
                .disabled(controller.controlState.zoomRange.lowerBound == controller.controlState.zoomRange.upperBound)
            }

            HStack {
                Image(systemName: "sun.max")
                Slider(
                    value: Binding(
                        get: { Double(controller.controlState.exposure) },
                        set: { controller.setExposure(Float($0)) }
                    ),
                    in: safeRange(controller.controlState.exposureRange)
                )
                .disabled(controller.controlState.exposureRange.lowerBound == controller.controlState.exposureRange.upperBound)
            }
        }
    }

    @ViewBuilder
    private var blockingStatusOverlay: some View {
        switch controller.availability {
        case .unknown, .requestingPermissions, .configuring:
            ZStack {
                Color.black.opacity(0.72).ignoresSafeArea()
                ProgressView(statusText)
                    .tint(.white)
            }
        case .failed(let message):
            ZStack {
                Color.black.opacity(0.86).ignoresSafeArea()
                VStack(spacing: 16) {
                    Image(systemName: "camera.badge.ellipsis")
                        .font(.system(size: 42))
                    Text(message)
                        .multilineTextAlignment(.center)
                    Button("打开系统设置") {
                        guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
                        UIApplication.shared.open(url)
                    }
                    .buttonStyle(.borderedProminent)
                }
                .padding(30)
            }
        case .interrupted(let message):
            ZStack {
                Color.black.opacity(0.72).ignoresSafeArea()
                Text(message).multilineTextAlignment(.center).padding(30)
            }
        case .ready:
            EmptyView()
        }
    }

    private var statusText: String {
        switch controller.availability {
        case .requestingPermissions: return "正在请求权限…"
        case .configuring: return "正在启动双摄…"
        default: return "正在准备相机…"
        }
    }

    private func handleTap(at point: CGPoint, canvasSize: CGSize) {
        let pipRect = controller.pipLayout.rect(in: canvasSize)
        let role: CameraRole
        let normalized: CGPoint
        if controller.dualCameraActive, pipRect.contains(point) {
            role = controller.pipRole
            normalized = CGPoint(
                x: (point.x - pipRect.minX) / pipRect.width,
                y: (point.y - pipRect.minY) / pipRect.height
            )
        } else {
            role = controller.mainRole
            normalized = CGPoint(x: point.x / canvasSize.width, y: point.y / canvasSize.height)
        }
        controller.select(role)
        controller.focus(at: normalized, for: role)
    }

    private func fittedSize(aspectRatio: CGFloat, inside container: CGSize) -> CGSize {
        guard aspectRatio > 0, container.width > 0, container.height > 0 else { return .zero }
        let containerAspect = container.width / container.height
        if containerAspect > aspectRatio {
            return CGSize(width: container.height * aspectRatio, height: container.height)
        }
        return CGSize(width: container.width, height: container.width / aspectRatio)
    }

    private func safeRange<T: BinaryFloatingPoint>(_ range: ClosedRange<T>) -> ClosedRange<Double> {
        let lower = Double(range.lowerBound)
        let upper = Double(range.upperBound)
        return lower < upper ? lower...upper : lower...(lower + 0.001)
    }
}

#Preview {
    CameraScreen()
}
