import CoreImage
import MetalKit
import SwiftUI

struct MetalPreviewView: UIViewRepresentable {
    let store: PreviewFrameStore

    func makeCoordinator() -> Coordinator {
        Coordinator(store: store)
    }

    func makeUIView(context: Context) -> MTKView {
        let view = MTKView(frame: .zero, device: MTLCreateSystemDefaultDevice())
        view.delegate = context.coordinator
        view.framebufferOnly = false
        view.enableSetNeedsDisplay = false
        view.isPaused = false
        view.preferredFramesPerSecond = 30
        view.colorPixelFormat = .bgra8Unorm
        view.clearColor = MTLClearColorMake(0, 0, 0, 1)
        return view
    }

    func updateUIView(_ uiView: MTKView, context: Context) {}

    final class Coordinator: NSObject, MTKViewDelegate {
        private let store: PreviewFrameStore
        private let context: CIContext
        private let commandQueue: MTLCommandQueue?
        private let colorSpace = CGColorSpaceCreateDeviceRGB()

        init(store: PreviewFrameStore) {
            self.store = store
            if let device = MTLCreateSystemDefaultDevice() {
                context = CIContext(mtlDevice: device, options: [.cacheIntermediates: false])
                commandQueue = device.makeCommandQueue()
            } else {
                context = CIContext(options: [.cacheIntermediates: false])
                commandQueue = nil
            }
        }

        func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {}

        func draw(in view: MTKView) {
            guard
                let frame = store.latestFrame(),
                let drawable = view.currentDrawable,
                let commandBuffer = commandQueue?.makeCommandBuffer()
            else { return }

            let source = CIImage(cvPixelBuffer: frame)
            let target = CGRect(origin: .zero, size: view.drawableSize)
            let scale = min(target.width / source.extent.width, target.height / source.extent.height)
            let scaled = source.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
            let centered = scaled.transformed(by: CGAffineTransform(
                translationX: target.midX - scaled.extent.midX,
                y: target.midY - scaled.extent.midY
            ))
            let background = CIImage(color: .black).cropped(to: target)
            let output = centered.composited(over: background)

            context.render(
                output,
                to: drawable.texture,
                commandBuffer: commandBuffer,
                bounds: target,
                colorSpace: colorSpace
            )
            commandBuffer.present(drawable)
            commandBuffer.commit()
        }
    }
}
