import CoreGraphics
import Foundation

struct PictureInPictureLayout: Equatable {
    static let minimumWidthFraction: CGFloat = 0.20
    static let maximumWidthFraction: CGFloat = 0.45
    static let edgeMarginFraction: CGFloat = 0.02

    var center = CGPoint(x: 0.78, y: 0.23)
    var widthFraction: CGFloat = 0.30

    func rect(in size: CGSize) -> CGRect {
        guard size.width > 0, size.height > 0 else { return .zero }
        let clampedWidth = min(max(widthFraction, Self.minimumWidthFraction), Self.maximumWidthFraction)
        let width = size.width * clampedWidth
        // The PiP uses the same aspect ratio as the full composition.
        let height = size.height * clampedWidth
        let proposed = CGRect(
            x: center.x * size.width - width / 2,
            y: center.y * size.height - height / 2,
            width: width,
            height: height
        )
        return Self.clamp(proposed, inside: CGRect(origin: .zero, size: size))
    }

    mutating func move(to point: CGPoint, in size: CGSize) {
        guard size.width > 0, size.height > 0 else { return }
        center = CGPoint(x: point.x / size.width, y: point.y / size.height)
        let clampedRect = rect(in: size)
        center = CGPoint(x: clampedRect.midX / size.width, y: clampedRect.midY / size.height)
    }

    mutating func resize(by scale: CGFloat, in size: CGSize) {
        widthFraction = min(
            max(widthFraction * scale, Self.minimumWidthFraction),
            Self.maximumWidthFraction
        )
        let clampedRect = rect(in: size)
        if size.width > 0, size.height > 0 {
            center = CGPoint(x: clampedRect.midX / size.width, y: clampedRect.midY / size.height)
        }
    }

    func contains(_ point: CGPoint, in size: CGSize) -> Bool {
        rect(in: size).contains(point)
    }

    private static func clamp(_ rect: CGRect, inside bounds: CGRect) -> CGRect {
        let marginX = bounds.width * edgeMarginFraction
        let marginY = bounds.height * edgeMarginFraction
        let safeBounds = bounds.insetBy(dx: marginX, dy: marginY)
        var result = rect
        result.origin.x = min(max(result.origin.x, safeBounds.minX), safeBounds.maxX - result.width)
        result.origin.y = min(max(result.origin.y, safeBounds.minY), safeBounds.maxY - result.height)
        return result
    }
}

final class CaptureLayoutStore {
    struct Snapshot {
        let layout: PictureInPictureLayout
        let mainRole: CameraRole
        let orientation: CaptureOrientation
    }

    private let lock = NSLock()
    private var layout = PictureInPictureLayout()
    private var mainRole: CameraRole = .back
    private var orientation: CaptureOrientation = .portrait

    func update(layout: PictureInPictureLayout? = nil, mainRole: CameraRole? = nil, orientation: CaptureOrientation? = nil) {
        lock.lock()
        defer { lock.unlock() }
        if let layout { self.layout = layout }
        if let mainRole { self.mainRole = mainRole }
        if let orientation { self.orientation = orientation }
    }

    func snapshot() -> Snapshot {
        lock.lock()
        defer { lock.unlock() }
        return Snapshot(layout: layout, mainRole: mainRole, orientation: orientation)
    }
}
