import AVFoundation
import CoreGraphics
import Foundation

enum CameraRole: String, CaseIterable, Equatable {
    case back
    case front

    var title: String {
        switch self {
        case .back: return "后摄"
        case .front: return "前摄"
        }
    }

    var opposite: CameraRole {
        self == .back ? .front : .back
    }
}

enum CaptureMode: String, CaseIterable, Equatable {
    case photo
    case video

    var title: String {
        switch self {
        case .photo: return "照片"
        case .video: return "视频"
        }
    }
}

enum CaptureAvailability: Equatable {
    case unknown
    case requestingPermissions
    case configuring
    case ready(dualCamera: Bool)
    case interrupted(String)
    case failed(String)

    var isReady: Bool {
        if case .ready = self { return true }
        return false
    }
}

enum RecordingState: Equatable {
    case idle
    case preparing
    case recording(startedAt: Date)
    case finishing
    case failed(String)

    var isBusy: Bool {
        switch self {
        case .preparing, .recording, .finishing: return true
        case .idle, .failed: return false
        }
    }

    var isRecording: Bool {
        if case .recording = self { return true }
        return false
    }
}

enum RecordingEvent: Equatable {
    case requestStart
    case firstFrame(Date)
    case requestStop
    case finish
    case fail(String)
    case reset
}

struct RecordingStateMachine {
    private(set) var state: RecordingState = .idle

    @discardableResult
    mutating func handle(_ event: RecordingEvent) -> RecordingState {
        switch (state, event) {
        case (.idle, .requestStart), (.failed, .requestStart):
            state = .preparing
        case (.preparing, .firstFrame(let date)):
            state = .recording(startedAt: date)
        case (.preparing, .requestStop), (.recording, .requestStop):
            state = .finishing
        case (.finishing, .finish), (.failed, .reset):
            state = .idle
        case (_, .fail(let message)):
            state = .failed(message)
        default:
            break
        }
        return state
    }
}

struct CameraControlState: Equatable {
    var zoom: CGFloat = 1
    var zoomRange: ClosedRange<CGFloat> = 1...1
    var exposure: Float = 0
    var exposureRange: ClosedRange<Float> = 0...0
}

enum CaptureSupport {
    enum Decision: Equatable {
        case dualCamera
        case singleCamera(reason: String)
    }

    static func decide(isMultiCamSupported: Bool, pairSupported: Bool) -> Decision {
        guard isMultiCamSupported else {
            return .singleCamera(reason: "这台设备不支持同时使用多颗摄像头，已切换为后置单摄。")
        }
        guard pairSupported else {
            return .singleCamera(reason: "前后摄像头不能组成可用的双摄组合，已切换为后置单摄。")
        }
        return .dualCamera
    }
}

enum CaptureOrientation: Equatable {
    case portrait
    case portraitUpsideDown
    case landscapeLeft
    case landscapeRight

    var outputSize: CGSize {
        switch self {
        case .portrait, .portraitUpsideDown:
            return CGSize(width: 1080, height: 1920)
        case .landscapeLeft, .landscapeRight:
            return CGSize(width: 1920, height: 1080)
        }
    }

    var rotationAngle: CGFloat {
        switch self {
        case .portrait: return 90
        case .portraitUpsideDown: return 270
        case .landscapeLeft: return 0
        case .landscapeRight: return 180
        }
    }
}

enum CaptureError: LocalizedError {
    case permissionsDenied
    case cameraUnavailable
    case configurationFailed(String)
    case recordingFailed(String)
    case saveFailed(String)

    var errorDescription: String? {
        switch self {
        case .permissionsDenied:
            return "需要相机、麦克风和相册写入权限。请前往系统设置开启。"
        case .cameraUnavailable:
            return "没有找到可用的摄像头。"
        case .configurationFailed(let message):
            return "相机配置失败：\(message)"
        case .recordingFailed(let message):
            return "录像失败：\(message)"
        case .saveFailed(let message):
            return "保存失败：\(message)"
        }
    }
}

